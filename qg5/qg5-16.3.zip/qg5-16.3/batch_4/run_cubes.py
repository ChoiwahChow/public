#!/usr/bin/python3

"""
Runs all cubes in parallel

Mace4 options:
-A-1   print the models in the format expected by isofilter


grep "Exiting with " semi_working_[0-9]/mace.log | grep model | utils/mace4/counter.py

"""


from datetime import datetime
import sys
import os
import time
import subprocess
import threading
import ast


cntrl_file = ".pause_running"
wait_period = 1
pause_period = 60
check_pos = 100000
max_batch_size=2000

request_work_file = "request_work.txt"
work_file = "release_work.out"


def thread_available(thread_count, thread_slots):
    if os.path.isfile(cntrl_file):
        time.sleep(pause_period)
        return -1
    for x in range(thread_count):
        if thread_slots[x] == 0:
            return x
    return -1


def all_done(thread_slots):
    for x in range(len(thread_slots)):
        if thread_slots[x] != 0:
            return False
    return True


def run_a_job(id, slot_id, thread_slots, mace_exec, input_files, cubes, run_opts, cubes_options, working_dir_prefix):
    """  run_opts (str):   e.g. "-n12 -A1 -O0 -M3 -m-1 -W-1"
    """
    working_dir = f"{working_dir_prefix}_{slot_id}"
    os.makedirs(working_dir, exist_ok=True)
    with (open(f"{working_dir}/cube.config", "w")) as fp:
        for cube in cubes:
            fp.write(f"{cube}\n")

    subprocess.run (f"cd {working_dir}; {mace_exec} {run_opts} -d{cubes_options} -f {' '.join(input_files)} >> mace.log 2>&1", 
                    capture_output=False, text=True, check=False, shell=True)
    thread_slots[slot_id] = 0

def request_work(working_dir_prefix, request_work_file, work_file, max_threads, thread_slots):
    print("debug request_work*****************\n")
    requested = False
    done = False
    first_round = True
    last_round = 0
    work_list = list()
    while not done:
        all_threads_completed = True
        for index, thread in enumerate(thread_slots):
            r_file_path = f"{working_dir_prefix}_{index}/{request_work_file}"
            c_file_path = f"{working_dir_prefix}_{index}/{work_file}"
            if os.path.exists(c_file_path):
                with (open(c_file_path)) as fp:
                    x = fp.read().splitlines()
                if x[-1].startswith("End"):
                    work_list.extend(x[:-1])
                    if os.path.exists(c_file_path):
                        os.remove(c_file_path)
                    if os.path.exists(r_file_path):
                        os.remove(r_file_path)
            if thread == 0:
                if os.path.exists(r_file_path):
                    os.remove(r_file_path)
            elif os.path.exists(f"{working_dir_prefix}_{index}"):
                all_threads_completed = False
                if last_round > 0:
                    if os.path.exists(r_file_path):
                        os.remove(r_file_path)
                elif first_round:
                    open(r_file_path, 'w').close()
                    requested = True
        if all_threads_completed:
            return work_list
        first_round = False
        if not requested:
            return work_list     # no active threads, so return
        time.sleep(2)
        if work_list:   # harvested something, ready to return
            if last_round > 1:
                done = True
            last_round += 1
    return work_list


def run_mace_jobs(mace4_exec, input_files, all_cubes, run_opts, cubes_options, 
                  working_dir_prefix, id_counter, last_counter, max_threads, thread_slots):
    """ 
    Args:
        mace4_exec (str): mace4 executable
        input_files (str): algebra input files
        all_cubes (List[int]):     list of cubes  
        run_opts (str):  e.g. "-P0 -m-1 -W-1 -O0 -M3"
        cubes_options (int): bit-0  use work stealing
        working_dir_prefix (str):   prefix of working_dir
        id_counter (int):   jobs finished or being finished so far
        max_threads (int):  maximum number of concurrent mace processes
        thread_slots(List[int]): array of slots for threads
    """

    input_file_paths = ["../" + x for x in input_files]
    mace4_exec_path = f"../{mace4_exec}"

    while all_cubes:
        num = max_batch_size
        if len(all_cubes) < 50:
            num = 5
        elif len(all_cubes) < 1000:
            num = 100

        cubes_to_run = all_cubes[:num]
        all_cubes = all_cubes[num:]
        
        slot_id = thread_available(max_threads, thread_slots)
        while slot_id < 0:
            time.sleep(wait_period)
            slot_id = thread_available(max_threads, thread_slots)
        id_counter += num
        if id_counter >= last_counter + check_pos:
            print(f"Doing {id_counter}", flush=True)
            last_counter += check_pos;
        thread_slots[slot_id] = threading.Thread(target=run_a_job,
                                                 args=(id, slot_id, thread_slots, mace4_exec_path, input_file_paths,
                                                       cubes_to_run, run_opts, cubes_options, working_dir_prefix))
        thread_slots[slot_id].start()
    return id_counter, last_counter


def run_mace(mace4_exec, input_files, cubes, run_opts, cubes_options, working_dir_prefix, max_threads):
    """  mace4_exec (string):    mace exec
         input_files (List[string]):    list of input files
         order (int):                   order of algebra
    """
    done = False
    thread_slots = [0] * max_threads
    cube_file = cubes
    steal_work = cubes_options % 2 == 1
    if steal_work:
        os.makedirs(f"{working_dir_prefix}_stealing", exist_ok=True)
        stealing_file = f"{working_dir_prefix}_stealing/new_work.out"
    id_counter = 0
    last_counter = 0

    with (open(cube_file)) as fp:
        all_cubes = fp.read().splitlines()
    all_cubes = [x.rstrip() for x in all_cubes]

    while all_cubes:
        id_counter, last_counter = run_mace_jobs(mace4_exec, input_files, all_cubes, run_opts, cubes_options,
                                                 working_dir_prefix, id_counter, last_counter, max_threads, thread_slots)
        if steal_work:
            all_cubes = request_work(working_dir_prefix, request_work_file, work_file, max_threads, thread_slots)
            print(f"{datetime.now().strftime('%d/%m/%Y %H:%M:%S')} run_mace, request work returns {len(all_cubes)} cubes", flush=True)
        else:
            all_cubes = []

    print(f'{datetime.now().strftime("%d/%m/%Y %H:%M:%S")} run_mace: All cubes are dispatched. Waiting for the last ones to finish...', flush=True)
    while(not all_done(thread_slots)):
        time.sleep(5)
        


__all__ = ["run_mace"]

if __name__ == "__main__":
    
    mace4_exec = "../bin/mace4c"
    input_files = "../inputs/alt-qg5.in"
    cubes_options = 1   # bit-0 for work stealing
    
    run_opts = "-n16 -O0 -M5 -m-1 -A-1 "
    max_threads = int(sys.argv[1])
    cubes_file = sys.argv[2]      # "e.g. order12_25_00a.out"
    thread_prefix = sys.argv[3]   # "e.g. qg3-12-23"
    
    print(f'{datetime.now().strftime("%d/%m/%Y %H:%M:%S")} starting the batch', flush=True)    
    start_time = time.time()

    run_mace(mace4_exec, [f"{input_files}"], cubes_file,
             run_opts, cubes_options, thread_prefix, max_threads)
    
    run_time = int(time.time() - start_time)
    print(f'{datetime.now().strftime("%d/%m/%Y %H:%M:%S")} done with batch in {run_time} seconds', flush=True)    
    
    

