#!/bin/bash
# running this script, e.g.
# nohup ./par_run.sh 0 20 > logs/par_20.log 2>&1 &

batch_no=$1
num_threads=$2
work_dir=batch_${batch_no}

mkdir ${work_dir}

# run under batch_${batch_no} directory, one level below top dir

cd ${work_dir}
cp ../run_cubes.py .

prefix="alt-qg5-16-33"
log_file="../logs/par_${batch_no}.log"
data_file="../data/${prefix}.O0M5.${batch_no}.data"


echo "Started: " >> ${log_file}
date >> ${log_file}


# set up logging
echo `hostname` >> ${log_file}
echo "batch number: " ${batch_no}  >> ${log_file}
echo "num_threads: "  ${num_threads} >> ${log_file}

./run_cubes.py ${num_threads} ${data_file} ${prefix} >> ${log_file} 2>&1 

# manually check results periodically

# When the run completes
# Sum up the User CPU for each run reported by mace4c - this is single CPU-hours used by the process
echo "Total user CPU-hours" >> ${log_file}
grep User_CPU ${prefix}_*/mace.log | awk -F "=" '{print $2}' | awk -F "," '{print $1}' | awk '{s+=$1}END{print s/3600}' >> ${log_file}

echo "checking results: cubes searched:  " >> ${log_file}
grep "Debug Cube::initialize_cube" ${prefix}_*/mace.log  | wc -l >> ${log_file}
echo "checking errors: " >> ${log_file}
grep -i "err" ${prefix}_*/mace.log | wc -l >> ${log_file}


echo "filtering for non-iso models: " >> ${log_file}
cat ${prefix}*/models.out | ../bin/isonaut > noniso_models.out 2>&1
tail -7 noniso_models.out >> ${log_file}

echo "Finished: " >> ${log_file}
date >> ${log_file}
