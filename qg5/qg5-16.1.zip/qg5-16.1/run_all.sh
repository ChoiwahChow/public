#!/bin/bash

date >> logs/run_all.log
./par_run.sh 0 20  > logs/par_0.log 2>&1 
./par_run.sh 1 20  > logs/par_1.log 2>&1 
./par_run.sh 2 20  > logs/par_2.log 2>&1 
./par_run.sh 3 20  > logs/par_3.log 2>&1 
./par_run.sh 4 20  > logs/par_4.log 2>&1 
./par_run.sh 5 20  > logs/par_5.log 2>&1 
./par_run.sh 6 20  > logs/par_6.log 2>&1 
./par_run.sh 7 20  > logs/par_7.log 2>&1 
./par_run.sh 8 20  > logs/par_8.log 2>&1 
./par_run.sh 9 20  > logs/par_9.log 2>&1 

cat batch_*/noniso_models.out | bin/isonaut > logs/noniso_models_16.out 2>&1

date >> logs/run_all.log
