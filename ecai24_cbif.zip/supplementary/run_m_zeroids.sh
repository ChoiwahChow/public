# m_zeroids

infile="inputs/m_zeroids.in"
for order in {7..9}
do
  echo "Now doing order ${order}"
  outfile=outputs/isonaut/m_zeroids_${order}_noniso.out
  outputfile=outputs/m_zeroids_${order}_noniso.out
  workingfile=working/m_zeroids_${order}_all.out
  # isomorph-free
  ./bin/mace4 -n${order} -m-1 -O3 -W-1 -A-1 -a ${outfile} -f ${infile} > ${outputfile} 2>&1

  # 2-step
  rm -f ${workingfile}
  ./bin/mace4 -n${order} -m-1 -O3 -A-1 -a ${workingfile} -f ${infile} > outputs/m_zeroids_${order}_all.out 2>&1
  ./bin/isonaut working/m_zeroids_${order}_all.out > outputs/isonaut/m_zeroids_${order}_all.out 2>&1
done


for order in {10..12}
do
  echo "Now doing order ${order}"
  outputfile=outputs/m_zeroids_${order}_noniso.out
  # isomorph-free, count only
  ./bin/mace4 -n${order} -m-1 -O3 -P0 -W-1 -f ${infile} > ${outputfile} 2>&1
done

