#!/usr/bin/bash

# involutive lattices
# Compares CBIF with 2-step methods for orders 9 to 12
# Count #models for orders 13 to 18

for order in {9..12}
do
  echo "Now doing order ${order}"
  # isomorph-free
  ./bin/mace4 -n${order} -A-1 -O0 -M0 -m-1 -W-1 -a outputs/isonaut/involutive_lattices_${order}_noniso.out -f inputs/involutive_lattices.in > outputs/involutive_lattices_${order}_noniso.out 2>&1

  # 2-step
  rm -f working/involutive_lattices_${order}.out
  ./bin/mace4 -n${order} -m-1 -A-1 -a working/involutive_lattices_${order}.out -f inputs/involutive_lattices.in > outputs/involutive_lattices_${order}.out 2>&1
  ./bin/isonaut working/involutive_lattices_${order}.out > outputs/isonaut/involutive_lattices_${order}.out 2>&1
done

for order in {13..18}
do
  echo "Now doing order ${order}"
  # isomorph-free, count only
  ./bin/mace4 -n${order} -P0 -m-1 -O0 -M0 -W-1 -f inputs/involutive_lattices.in > outputs/involutive_lattices_${order}_noniso.out 2>&1
done

