#define PROGRAM_DATE     "SEP 2023"
#define PROGRAM_VERSION  "2023-09-A"
#define INSTITUTION      "Universidade Aberta"
