#ifndef TP_WEIGHT2_H
#define TP_WEIGHT2_H

#include "term.h"


class Weight2 {
				private:
						static int char_array_ident(char*, char*, int);
						static int char_array_find(char *, int, char *, int);
						static double complexity_1(char *);
						static double test1(Term);

				
				public:
						
							static double call_weight(string, Term);

	
	
};


#endif
