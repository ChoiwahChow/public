#ifndef TP_INDEX_H
#define TP_INDEX_H

enum class Querytype    {
                            UNIFY,
                            INSTANCE,
                            GENERALIZATION,
                            VARIANT,
                            IDENTICAL
};

/* types of operation */

enum class Indexop {
                    INSERT,
                    DELETE
};

/* Public definitions */

/* End of public definitions */

/* Public function prototypes */

#endif
