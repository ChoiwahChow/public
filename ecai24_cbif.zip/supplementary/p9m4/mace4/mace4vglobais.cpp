#include "mace4vglobais.h"



Mace4VGlobais::Mace4VGlobais() {
  Opt = &opt;
  Arith = &arith;
}

Mace4VGlobais::~Mace4VGlobais() {
}
