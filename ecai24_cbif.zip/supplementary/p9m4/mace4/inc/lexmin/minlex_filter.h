

#pragma once

#include <vector>

bool minlex_isofilter(const std::vector<std::vector<int>>& binop);
