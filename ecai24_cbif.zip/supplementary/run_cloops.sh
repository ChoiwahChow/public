#!/usr/bin/bash

# count number of C loops of order 16

./bin/mace4 -n16 -m-1 -P0 -W-1 -O0 -M0 -f inputs/cloops.in > outputs/cloops_16.out 2>&1
