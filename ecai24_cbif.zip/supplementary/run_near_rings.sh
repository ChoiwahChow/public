#!/usr/bin/bash

# near rings, isomorph-free count only

for order in {14..15}
do
  echo "Now doing order ${order}"
  ./bin/mace4 -n${order} -m-1 -P0 -W-1 -f inputs/near_rings.in > outputs/near_rings_${order}_noniso.out 2>&1
done

