

rm -f outputs/*.out
rm -f outputs/isonaut/*.out
rm -f working/*.out
