#!/usr/bin/bash

# run iploops
for order in {13..15}
do
  echo "Now doing order ${order}"
  ./bin/mace4 -n${order} -m-1 -W-1 -o "*" -O0 -M0 -P0 -f inputs/iploops.in > outputs/iploops_${order}.out 2>&1
done
