#!/usr/bin/python3


import sys


def read_bin_model(fp) :
    done = False
    model = list()
    while not done:
        line = fp.readline()
        if not line:
            break
        line = line.replace(",", " ").replace("])", "").replace(".", "").strip()
        row = [int(x) for x in line.split()]
        model.append(row)
        if len(model) == len(row):
            done = True
    return model


def transpose_model(m):
    return list(map(list, zip(*m)))


def anti_iso(fn):
    m_count = 0
    all_models = list()
    with open(fn) as fp:
        done = False
        while not done:
            line = fp.readline()
            if not line:
                break
            if not "function" in line:
                continue
            m_count += 1
            m = read_bin_model(fp)
            t = transpose_model(m)
            if not t in all_models:
                all_models.append(m)
            else:
                print(m)

    print (f"Number of non-isomorphic models: {m_count}")
    print (f"Number of models up to isomorphism and anti-isomorphism: {len(all_models)}")


if __name__ == "__main__":
    anti_iso(sys.argv[1])
            
