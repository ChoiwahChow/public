#!/usr/bin/python3

from pynauty import *



def build_graph1():
    g = Graph(12)
    g.connect_vertex(0,  [2, 4, 6])
    g.connect_vertex(1,  [3, 5, 7])
    #g.connect_vertex(8,  [2, 4, 6])
    #g.connect_vertex(9,  [2, 5, 6])
    #g.connect_vertex(10,  [3, 4, 7])
    #g.connect_vertex(11,  [3, 5, 7])
    g.connect_vertex(2,  [8, 9])
    g.connect_vertex(3,  [9, 11])
    g.connect_vertex(4,  [8, 9])
    g.connect_vertex(5,  [10, 11])
    g.connect_vertex(6,  [8, 10])
    g.connect_vertex(7,  [9, 11])

    g.set_vertex_coloring([set([0, 1]), set([2, 3]), set([4, 5]), set([6, 7]), set([8, 9, 10, 11]) ])
    return g

def build_graph2():
    g = Graph(12)
    g.connect_vertex(0,  [2, 4, 6])
    g.connect_vertex(1,  [3, 5, 7])
    #g.connect_vertex(8,  [2, 4, 6])
    #g.connect_vertex(9,  [2, 5, 7])
    #g.connect_vertex(10,  [3, 4, 6])
    #g.connect_vertex(11,  [3, 5, 7])

    g.connect_vertex(2,  [8, 10])
    g.connect_vertex(3,  [9, 11])
    g.connect_vertex(4,  [8, 9])
    g.connect_vertex(5,  [10, 11])
    g.connect_vertex(6,  [8, 10])
    g.connect_vertex(7,  [9, 11])
    g.set_vertex_coloring([set([0, 1]), set([2, 3]), set([4, 5]), set([6, 7]), set([8, 9, 10, 11]) ])
    return g

def build_graph3():
    g = Graph(12)
    g.connect_vertex(0,  [2, 4, 6])
    g.connect_vertex(1,  [3, 5, 7])
    g.connect_vertex(8,  [2, 4, 6])
    g.connect_vertex(9,  [2, 5, 7])
    g.connect_vertex(10,  [3, 4, 7])
    g.connect_vertex(11,  [3, 5, 6])

    g.set_vertex_coloring([set([0, 1]), set([2, 3]), set([4, 5]), set([6, 7]), set([8, 9, 10, 11]) ])
    return g

def build_graph4():
    g = Graph(12)
    g.connect_vertex(0,  [2, 4, 6])
    g.connect_vertex(1,  [3, 5, 7])
    g.connect_vertex(8,  [2, 4, 7])
    g.connect_vertex(9,  [2, 5, 6])
    g.connect_vertex(10,  [3, 4, 6])
    g.connect_vertex(11,  [3, 5, 7])

    g.set_vertex_coloring([set([0, 1]), set([2, 3]), set([4, 5]), set([6, 7]), set([8, 9, 10, 11]) ])
    return g

def isonaut():
    """
    g3 = build_graph3()
    cg3 = canon_label(g3)
    print( cg3 )
    g4 = build_graph4()
    cg4 = canon_label(g4)
    print( cg4 )
    """

    res = isomorphic(build_graph1(), build_graph2())
    print(res)


if __name__ == "__main__":
    isonaut()

