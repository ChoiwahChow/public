/* isofilter.h : Mace4 style isofiltering. */
/* Version 1.1, July 2023. */


int test_iso_graph(size_t = 0);

