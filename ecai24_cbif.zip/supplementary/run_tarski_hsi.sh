#!/usr/bin/bash

# Tarski's HSI, isomorph-free, count only

for order in {5..6}
do
  echo "Now doing order ${order}"
  ./bin/mace4 -n${order} -m-1 -W-1 -O0 -M0 -P0 -f inputs/tarski_hsi.in > outputs/tarski_hsi_${order}.out 2>&1
done


