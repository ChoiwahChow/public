#!/usr/bin/bash

# Run mace4 on Tarski Algebras.
# For orders 9 to 12, enumerate models for both the 2-step procedure
# and the isomorph-free procedure
# For orders 14 to 23, only count the number of models because of the
# lack of disk space.

for order in {9..12}
do
  echo "Now doing order ${order}"
  # isomorph-free
  rm -f "outputs/isonaut/tarski_algebras_${order}_noniso.out"
  ./bin/mace4 -n${order} -O3 -m-1 -W-1 -A-1 -a "outputs/isonaut/tarski_algebras_${order}_noniso.out" -f inputs/tarski_algebras.in > outputs/tarski_algebras_${order}_noniso.out 2>&1

  # all
  rm -f working/tarski_algebras_${order}_all.out
  ./bin/mace4 -n${order} -O3 -m-1 -A-1 -a "working/tarski_algebras_${order}_all.out" -f inputs/tarski_algebras.in > outputs/tarski_algebras_${order}_all.out 2>&1
  ./bin/isonaut working/tarski_algebras_${order}_all.out > outputs/isonaut/tarski_algebras_${order}_all.out 2>&1
done

for order in {13..23}
do
  echo "Now doing order ${order}"
  # isomorph-free, count only
  ./bin/mace4 -n${order} -O3 -m-1 -W-1 -P0 -f inputs/tarski_algebras.in > outputs/tarski_algebras_${order}_noniso.out 2>&1
done

