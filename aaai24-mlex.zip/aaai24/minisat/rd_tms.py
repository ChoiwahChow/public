#!/usr/bin/python2.7
#
# As arguments expects a filename for each solver.
# Each file has the three columns: instance name, solving time, response
#

import string, sys, re
from html_utils import *

SUBOPTCOL="#4682B4"
WRONGCOL="#FF0000"
TOUTCOL="#FA8072"
UNIQUECOL="#00F000"
WINCOL="#00c010"
SOLVEDCOL="#00a86b"

def rf(f,inns,inn_list):
  d=dict()
  ln=0
  for line in f:
     ln=ln+1
     es=line.rsplit(';')
     if len(es) < 2: continue
#       sys.stderr.write('error on line ' + str(ln) + ': expecting at least 2 items\n')
     inn=es[0].strip()
     d[inn] = ( es[1].strip(), '' if len(es)<3 else es[2].strip() )
     if inn not in inns:
        inn_list.append(inn)
        inns.add(inn)

  return d

def common_suff(ls):
  if not ls: return None
  r=ls[0]
  for s in ls[1:]:
    pr = len(r)
    ps = len(s)
    while 0<pr and 0<ps and s[ps-1]==r[pr-1]:
      ps-=1
      pr-=1
    r = r[pr:]
  return r

def common_pref(ls):
  if not ls: return None
  r=ls[0]
  for s in ls[1:]:
    j = 0
    while j < len(s) and j < len(r) and s[j]==r[j]:
      j+=1
    r = r[:j]
  return r

def get_group(s):
    m=re.match('([0-9_]+)-.*', s)
    return m.group(1) if m else s


def print_summary(file_names):
  global wrongs,wins,solveds,uniques,ds
  rml=len(common_pref(file_names))
  rmr=len(common_suff(file_names))
  print >>sys.stderr, 'group, solved, subopt, wrong, wins, uniques'
  for i in range(len(ds)):
    s=file_names[i]
    print >>sys.stderr, ','.join(map(str, [ get_group(s[rml:len(s)-rmr]), solveds[i], subopts[i], wrongs[i], wins[i], uniques[i] ]))

def cutnm(i, file_names):
  rml=len(common_pref(file_names))
  rmr=len(common_suff(file_names))
  s = file_names[i];
  return s[rml:len(s)-rmr]

def print_header(file_names):
  rml=len(common_pref(file_names))
  rmr=len(common_suff(file_names))
  for s in file_names:
      phc(get_group(s[rml:len(s)-rmr]))

  # inm=s
  # m=re.match('([0-9_]+)-.*', inm)
  # inm = m.group(1) if m else inm
  # phc(inm)


inns=set()
inn_list=[]
ds=[]
for fn in sys.argv[1:]:
    sys.stderr.write('reading ' + fn + '\n')
    f = open(fn, 'r')
    d=rf(f,inns,inn_list)
    ds.append(d)
    f.close()

header()
print '<table border="1">'
print '<tr>'
print '<td bgcolor="#FA8072"> TIME/MEM OUT/ERR  </td>'
print '<td bgcolor="#F00000"> WRONG </td>'
print '<td bgcolor="{}"> SOLVED </td>'.format(SOLVEDCOL)
print '<td bgcolor="{}"> WIN </td>'.format(WINCOL)
print '<td bgcolor="{}"> UNIQUE </td>'.format(UNIQUECOL)
print '<td bgcolor="{}"> SUBOPTIMAL </td>'.format(SUBOPTCOL)
print '<td bgcolor="black"> <font color="white">NOT-RUN</font> </td>'
print '</tr>'
print '</table>'

otable()

print '<thead>'
print '<tr>'
phc('Problem')
print_header(sys.argv[1:])
print '</tr>'
print '</thead>'
print '<tbody>'

solveds = [ 0 for x in range(len(ds))]
wins    = [ 0 for x in range(len(ds))]
wrongs    = [ 0 for x in range(len(ds))]
subopts  = [ 0 for x in range(len(ds))]
uniques = [ 0 for x in range(len(ds))]
inn_names = []
inn_infos = []
for inn in inn_list:
  spl = inn.find('(')
  inn_names.append((inn[:spl] if spl >= 0 else inn).strip())
  inn_infos.append((inn[spl:] if spl >= 0 else '').strip())
inst_common_pref = common_pref(inn_names)
inst_common_suff = common_suff(inn_names)
for inn_pos in xrange(len(inn_list)):
   inn = inn_list[inn_pos]
   inn_name = inn_names[inn_pos]
   inn_info = inn_infos[inn_pos]
   print '<tr>'
   pc('bgcolor="#F1F1F1"',inn_name[len(inst_common_pref):len(inn_name)-len(inst_common_suff)]+' '+inn_info)
   ts=[]
   tsn=[]
   ads=[]
   # moves=[]
   availabe=[]
   for d in ds:
     if inn in d:
       (tstr,a)=d[inn]
       availabe.append(True)
     else:
       tstr='1000000'
       a='N/A'
       availabe.append(False)
     ts.append(tstr)
     ads.append(a)
   if a and a[0]=='s':
         tsn.append( float(tstr.split()[0]) )
         # moves.append(int(a.strip().split()[1]))
   # moves = [ int(ads[i].strip().split()[1]) for i in range(len(ts)) if availabe[i] and ads[i][0]=='s'  ]
   # minm=min(moves) if moves else None
   valid_tms = [ int(ts[i].split()[0]) for i in range(len(ts)) if availabe[i] and ads[i][0]=='s' ]
   mint=min(valid_tms) if valid_tms else 1000000
   unique=len(valid_tms)==1
   # rvs=set()
   for i in range(len(ts)):
     tstr=ts[i]
     ad=ads[i]
     tout=not ad or ad[0]!='s'
     wrong=ad and ad[0]=='w'
     t=float(tstr.split()[0]) if tstr else -1
     win=not tout and (t-mint)<1
     assert not tout or not win

     # if ad[0]=='s':
     #     rvs.add(ad)

     subopt = False

     if wrong: wrongs[i]=wrongs[i]+1
     if win: wins[i]=wins[i]+1
     if subopt: subopts[i]=subopts[i]+1
     if win and unique: uniques[i]=uniques[i]+1
     if not tout: solveds[i]=solveds[i]+1
     if availabe[i]:
         if subopt          : cell_style='bgcolor="{}"'.format(SUBOPTCOL)
         elif wrong         : cell_style='bgcolor="{}"'.format(WRONGCOL)
         elif tout          : cell_style='bgcolor="{}"'.format(TOUTCOL)
         elif win and unique: cell_style='bgcolor="{}"'.format(UNIQUECOL)
         elif win           : cell_style='bgcolor="{}"'.format(WINCOL)
         else               : cell_style='bgcolor="{}"'.format(SOLVEDCOL)
     else:
       cell_style = 'bgcolor="#000000"'
     cell_text = tstr + ('' if len(ad)==0 else '<br>'+ad )
     cell_text = '<span title="' + cutnm(i, sys.argv[1:]) + '">' + cell_text + '</span>'
     pc(cell_style, cell_text)
     # pc(cell_style, tstr + ('' if len(ad)==0 else '<br>'+ad ) )
   print '</tr>'
   # print >>sys.stderr, rvs
   # if len(rvs)>1:
   #     print >>sys.stderr, '!!! varying retv for', inn

print '<tr>'
pc('bgcolor="#F1F1F1"', 'TOTAL ('+str(len(inns))+')')
for i in range(len(ds)):
  pc('bgcolor="#F1F1F1"','solved:'+str(solveds[i])+'<br>wins:'+str(wins[i])+'<br>subopts:'+str(subopts[i])+'<br>wrongs:'+str(wrongs[i])+'<br>uniq:'+str(uniques[i]))
print '</tr>'

print '<tr>'
phc('')
print_header(sys.argv[1:])
print '</tr>'

print '</tbody>'

ctable()
cheader()
print_summary(sys.argv[1:])
