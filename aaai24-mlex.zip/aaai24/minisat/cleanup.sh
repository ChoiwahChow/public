

rm -rf logs
rm -f mlex_options.pdf
rm -rf tables
