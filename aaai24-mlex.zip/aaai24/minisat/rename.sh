cd tables
mv jobs_1800_15000_mlex-m_-1_-b_--budget-idem_-r_-l_-t_bin2.tab    bjobs_1800_15000_mlex-m-all_enhancedments.tab
mv jobs_1800_15000_mlex-m_--no-1_--no-b_--no-budget-idem_--no-r_--no-l_-t_lus.tab ajobs_1800_15000_mlex-m-basic_algorithm.tab
mv jobs_1800_15000_mlex-m_--no-1.tab     cjobs_1800_15000_mlex-m-w-o_first_row_identification.tab
mv jobs_1800_15000_mlex-m_--no-b_--no-budget-idem.tab       djobs_1800_15000_mlex-m-w-o_budgeting.tab
mv jobs_1800_15000_mlex-m_--no-budget-idem.tab           ejobs_1800_15000_mlex-m-w-o_mid-row_budgeting.tab
mv jobs_1800_15000_mlex-m_--no-r.tab               fjobs_1800_15000_mlex-m-w-o_invariants.tab
mv jobs_1800_15000_mlex-m_-t_lus.tab          gjobs_1800_15000_mlex-m-w-_strategy_lus.tab
