#!/bin/bash
if [[ $# < 3 ]]; then
    echo "Usage: $0 instance_directory log_directory solver"
    exit 100;
fi

function detect { # FILE PATTERN REPLACE
  GRES=`grep -e "${2}" "${1}" | tail -n -1 | sed -e 's/'"${2}"' \?/'"${3}:"'/'`
  if [ -n "${GRES}" ]; then
     echo -n " ("${GRES}")"
  fi
}

ID=${1}
LD=${2}
SV=${3}

SUFFIX=.dre
skipped=0
not_done=0
for FF in `ls ${1}/*${SUFFIX}`
do
  F=`basename $FF`
  SOLUTION_FILE=${2}/${F}.sol
  ERR_FILE=${2}/${F}.err
  W_FILE=${2}/${F}.w

  if [ ! -f ${W_FILE} ]; then
    let skipped=${skipped}+1
    let not_done=${not_done}+1
    continue
  fi

  if ! grep -q -e '^CPU user time ' ${W_FILE};
  then
	  let not_done=${not_done}+1
	  echo >&2 '++' missing: ${F}
	  continue
  fi

  _TIME=`grep -e '^CPU time (s):' ${W_FILE} | sed -e 's/CPU time (s)://'| sed 's/ //'`
  # _TIME_U=`grep -e '^CPU user time (s):' ${W_FILE} | sed -e 's/CPU user time (s)://'| sed 's/ //'`
  # _TIME_S=`grep -e '^CPU system time (s):' ${W_FILE} | sed -e 's/CPU system time (s)://'| sed 's/ //'`
  TIME=`printf "%0.f\n" ${_TIME}`
  # TIME_U=`printf "%0.f\n" ${_TIME_U}`
  # TIME_S=`printf "%0.f\n" ${_TIME_S}`
  #echo -n \; ${TIME} '('${TIME_U}'+'${TIME_S}')' '; '
  # STAT=`grep -e '^Child status:' ${W_FILE} | sed -e 's/Child status://' | sed 's/ //'`
  if ./dre_is_ok.sh ${FF} ${SOLUTION_FILE}; then
	  ANSWER="s"
  else
	  ANSWER='n'
  fi
  # detect ${ERR_FILE} '^horizon:' 'hz'
  #detect ${W_FILE} '^Max. virtual memory (cumulated for all children) (KiB):' 'mem'
  echo ${F%.dre} ';' ${TIME} "(sec)" ';' ${ANSWER}
done
# echo >&2 missing: ${skipped}
echo >&2 '+' missing: ${not_done}

if [ ${not_done} -eq 0 ]
then
	exit 0
else
	exit 1
fi
