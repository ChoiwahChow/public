def header():
  print '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">'
  print
  print '<HEAD>'
  print '  <TITLE>Detailed Results</TITLE>'
  print '</HEAD>'
  print '<BODY>'

def otable(): print '<table border="1">'
def ctable(): 
  print '</table>'
def cheader(): 
  print '</BODY>'

def pc(s,cs):
   print '<td ' + s  + '>',cs,'</td>'
def phc(cs):
   print '<th>',cs,'</th>'
