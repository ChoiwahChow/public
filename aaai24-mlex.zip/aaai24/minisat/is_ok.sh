#!/bin/bash
#
# File:  is_ok.sh
# Author:  mikolas
# Created on:  Wed Oct 30 14:14:55 WET 2019
# Copyright (C) 2019, Mikolas Janota
#
if [[ $# < 2 ]]; then
    echo "Usage: $0 instance solution"
    exit 100;
fi

if grep -q '^. Total time' $2; then
	exit 0
else
	exit 1
fi
