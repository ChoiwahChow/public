#!/usr/bin/bash

# clean up:
rm -rf logs tables

mkdir -p logs tables

# number of parallel processes
nump=$1

parallel -j ${nump} ./run_arg.sh mlex {1} {2} ::: `ls jobs/*` ::: "-m --no-1 --no-b --no-budget-idem --no-r --no-l -t lus" "-m -1 -b --budget-idem -r -l -t bin2" "-m --no-1" "-m --no-r" "-m --no-b --no-budget-idem" "-m -t lus" "-m --no-budget-idem" 

# short test
#parallel -j ${nump} ./run_arg.sh mlex {1} {2} ::: `ls jobs/*` ::: "-m -1 -b --budget-idem -r -l -t bin2" "-m -t lus" 

./render.sh jobs

./rename.sh

./plot.py `ls tables/*.tab` -o mlex_options
