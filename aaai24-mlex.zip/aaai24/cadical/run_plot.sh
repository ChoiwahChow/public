#!/usr/bin/bash

./cleanup.sh
mkdir -p logs tables

nump=$1

parallel -j ${nump} ./run_arg.sh mlex {1} {2} ::: `ls jobs/*` ::: "-m --no-1 --no-b --no-budget-idem --no-r --no-l -t lus" "-m -1 -b --budget-idem -r -l -t bin2" "-m --no-b --no-budget-idem" 

./render.sh jobs

# ./plot.py `ls tables/*.tab` -o cadical_mlex_options


