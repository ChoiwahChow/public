

rm -rf logs
rm -f cadical_mlex_options.pdf
rm -rf tables
