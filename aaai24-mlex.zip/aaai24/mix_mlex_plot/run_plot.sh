#!/usr/bin/bash


# cleanup old runs first
rm -f tables/*
rm -f mix_mlex_plot.pdf

mkdir -p tables

cp ../minisat/tables/bjobs_1800_15000_mlex-m-all_enhancedments.tab                                  tables/bminisat_all_enhancements.tab
# cp ../minisat/tables/djobs_1800_15000_mlex-m-w-o_budgeting.tab                                      tables/dminisat_w-o_budgeting.tab
cp ../minisat/tables/ajobs_1800_15000_mlex-m-basic_algorithm.tab                                    tables/fminisat_basic_algorithm.tab

cp ../cadical/tables/jobs_1800_15000_mlex-m_-1_-b_--budget-idem_-r_-l_-t_bin2.tab                   tables/acadical_all_enhancements.tab
# cp ../cadical/tables/jobs_1800_15000_mlex-m_--no-b_--no-budget-idem.tab                             tables/ccadical_w-o_budgeting.tab
cp ../cadical/tables/jobs_1800_15000_mlex-m_--no-1_--no-b_--no-budget-idem_--no-r_--no-l_-t_lus.tab tables/ecadical_basic_algorithm.tab

./plot.py `ls tables/*.tab` -o mix_mlex_plot
