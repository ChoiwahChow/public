#!/usr/bin/env python3
# File:  plot.py
# Author:  mikolas
# Created on:  Fri Apr 30 01:26:42 CEST 2021
# Copyright (C) 2021, Mikolas Janota
import argparse
import sys
import math
import matplotlib.pyplot as plt
CB_color_cycle = ['#377eb8', '#ff7f00', '#4daf4a',
                  '#f781bf', '#a65628', '#984ea3',
                  '#999999', '#e41a1c', '#dede00']
linestyles = [
    {'c': CB_color_cycle[0], 'marker': '>'},
    {'c': CB_color_cycle[1], 'marker': 'o'},
    {'c': CB_color_cycle[2], 'marker': '<'},
    {'c': CB_color_cycle[3], 'marker': '*'},
    {'c': CB_color_cycle[4], 'marker': '.'},
    {'c': CB_color_cycle[5], 'marker': '+'},
    {'c': CB_color_cycle[6], 'marker': '1'},
    {'c': CB_color_cycle[7], 'marker': '2'},
    {'c': CB_color_cycle[8], 'marker': '3'},
    {'c': CB_color_cycle[0], 'marker': '4'},
    {'c': CB_color_cycle[1], 'marker': 's'},
    {'c': CB_color_cycle[2], 'marker': 'd'},
    {'c': CB_color_cycle[3], 'marker': 'D'},
    {'c': CB_color_cycle[0], 'marker': 'o'},
    {'c': CB_color_cycle[3], 'marker': '*'},
    {'c': CB_color_cycle[4], 'marker': '>'},
    {'c': CB_color_cycle[5], 'marker': '<'},
    {'c': CB_color_cycle[6], 'marker': '1'},
    {'c': CB_color_cycle[7], 'marker': '2'},
]


def prepare_figure_style(subplot_count):
    """
    Prepares the style of the figure.
    """

    fig_width_pt = 252.0  # Get this from LaTeX using \showthe\columnwidth
    inches_per_pt = 1.0 / 72.27                           # Convert pt to inch
    golden_mean = (math.sqrt(5) + 1.0) / 2.0                # Aesthetic ratio
    fig_width = fig_width_pt * inches_per_pt + 0.2        # width in inches
    fig_height = fig_width / golden_mean * subplot_count + 0.395 * (subplot_count - 1)  # height in inches
    fig_size = [fig_width, fig_height]

    params = {'backend': 'pdf',
              'axes.labelsize': 5,
              'xtick.labelsize': 5,
              'ytick.labelsize': 5,
              'text.usetex': True,
              'figure.figsize': fig_size}

    plt.rcParams.update(params)


def common_suff(ls):
    if not ls: return None
    if len(ls)== 1: return ""
    r=ls[0]
    for s in ls[1:]:
        pr = len(r)
        ps = len(s)
        while 0<pr and 0<ps and s[ps-1]==r[pr-1]:
            ps-=1
            pr-=1
        r = r[pr:]
    return r

def common_pref(ls):
    if not ls: return None
    if len(ls)== 1: return ""
    r=ls[0]
    for s in ls[1:]:
        j = 0
        while j < len(s) and j < len(r) and s[j]==r[j]:
            j+=1
        r = r[:j]
    return r


def plot(output_name, lower_bound, solvers):
    """ Create plot """
    global linestyles
    solver_names = [solver.name for solver in solvers]
    rml = len(common_pref(solver_names))
    rmr = len(common_suff(solver_names))
    # print(common_pref(solver_names))
    # print(common_suff(solver_names))
    # print (solver_names,rml, rmr)
    plt.grid(True, color='black', ls=':', lw=0.1)
    # prepare_figure_style (1)
    sorted_solvers = solvers
    values = {value for solver in solvers for value in solver.values}
    if values:
        minimum_value = min(values)
        solved = any([solver.solved for solver in solvers])
        plt.axline((0, minimum_value), (180, minimum_value), linewidth=0.8,
                   color="red", linestyle=("-"  if solved  else "--"))
    if lower_bound is not None:
        plt.axline((0, lower_bound), (180, lower_bound), linewidth=0.8,
                   color="blue", linestyle=":")
    for index,solver in  enumerate(sorted_solvers):
        #print(f"******************{solver.name}****************")
        #solver_label = solver.name[rml:len(solver.name)-rmr] + (" (solved)" if  solver.solved else "")
        #print(f"******************{in_label}****************")
        solver_label = solver.name.replace("tables/", "")[1:].replace(".tab", "").replace("w-", "w/").replace("_", " ")
        # solver_label = labels.get(solver_label, solver_label)
        print("plotting:", solver_label)
        plt.plot(solver.values, solver.times,
                 linewidth=0.2, label=solver_label, **linestyles[index])
    plt.legend(prop={'size': 9})
    # print("solver", end="")
    # for solver in sorted_solvers:
    #     solver_label = solver.name[rml:len(solver.name)-rmr] + (" (solved)" if  solver.solved else "")
    #     print(f" & {solver_label}", end="")
    # print(" \\\\")
    # print(output_name, end="")
    # for solver in sorted_solvers:
    #     if minimum_value is not None and solver.values[-1] == minimum_value:
    #         print(f" & \\textbf{{{solver.values[-1]}}}", end="")
    #     else:
    #         print(f" & {solver.values[-1]}", end="")
    # print(" \\\\")

    # plt.xticks(range(0, len (values) + 2, 20))   #re-added
    plt.xlabel('instances')
    plt.ylabel('CPU time (s)')
    plt.savefig(output_name + ".pdf")

def report(message):
    """  Report a message to standard error."""
    print(message, file=sys.stderr)

class Solver:
    """  Information about a solver."""

    def __init__(self, name):
        self.name = name
        self.times = []
        self.values = []
        self.solved = False

    def add(self, time, value):
        self.times.append(time)
        self.values.append(value)


def parse_time(time):
    return float(time.strip().split()[0])    #changed
    elements = time.split(":")
    assert len(elements) == 2
    result = elements[1]
    assert result[-1] == "s"
    return float(result[:-1])


def read_solvers(input_files):
    """ Read solvers from a sequence of tab files."""
    solvers = []
    for file_name in input_files:
        with open(file_name) as input_file:
            solver = Solver(file_name)
            contents = input_file.readlines()
            all_lines = [float(x.split(" ")[2]) for x in contents if " ; n" not in x]
            all_times = sorted(all_lines)
            for value, time in enumerate(all_times):
                #if line.startswith('v '):
                #    solver.solved = True
                #    continue
                #if not line.startswith('o '):   #changed
                #    continue
                #elements = line.split(";")   #changed from " " to ";"
                #print(elements)
                #if not (len(elements) == 4 or len(elements) == 3):
                #    continue
                #time = parse_time(elements[1])   #changed from 2 to 1
                #value = 1   #changed int(elements[1])
                if time >= 1800:
                    #solver.solved = False
                    continue
                solver.add(time, value)
            if solver is not None:
                solvers.append(solver)
    return solvers


def main_run(options):
    """ main run of the program."""
    solvers = read_solvers(options.input_file)
    plot(options.output_file,options.lower_bound, solvers)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description='Set cover, solver runtime processing.')
    parser.add_argument('input_file', nargs='+', type=str, default=None,
                        help='Read from files.')
    parser.add_argument('-o', dest='output_file', type=str, default="plot")
    parser.add_argument('-l', dest='lower_bound', type=float, default=None)
    main_run(parser.parse_args())

