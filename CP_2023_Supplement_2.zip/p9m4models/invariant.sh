
date;

rm -rf *_working_* models.out working__* outputs__*

k=$1
a=invol_lattices

../bin/mace4 -n${k} -N${k} -m-1 -A1 -f ../inputs/50_invol_lattices.in

w=working__${k}
o=outputs__${k}

rm -rf ${w} ${o} parallel

mkdir parallel
mkdir ${w}
mkdir ${o}

../bin/splitModels -d${k} -f"../bin/isofilter -ignore_constants " -m1 -o${w}/ni_ -t${w}/stat.json -u2910948 -s1000 -r50 -l20 -x2912 -i"models.out" -p30


echo "non iso found: "
grep interp ${w}/*.f | wc -l

date

