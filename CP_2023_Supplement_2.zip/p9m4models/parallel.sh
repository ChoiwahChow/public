
date;

rm -rf *_working_* models.out

k=$2
l=$3
a=$1
n=$4

echo ${a} ${k} ${l} ${n}

utils/mace4/bootstrap.py ${a} ${k} ${l} ${n}

> models.out
for f in  *_working_*/models.out; do cat ${f} >> models.out; rm ${f}; done

wb=working__
ob=outputs__

w=${wb}${k}
o=${ob}${k}

rm -rf ${wb}* ${ob}* parallel

mkdir parallel
mkdir ${w}
mkdir ${o}

../bin/splitModels -d${k} -f"../bin/isofilter -ignore_constants" -m1 -o${w}/ni_ -t${w}/stat.json -u2910948 -s1000 -r50 -l20 -x2912 -i"models.out" -p${n}

echo "found non iso models: "
grep inter ${w}/ni_*.f | wc -l

echo ${a} ${k} ${l} ${n}

rm -rf utils/mace4/working

date

